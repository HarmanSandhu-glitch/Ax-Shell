import json
import os
import sys

def update_vscode_settings(generated_colors_path, settings_path):
    try:
        # Load generated colors
        with open(generated_colors_path, 'r') as f:
            new_colors = json.load(f)
        
        # Load existing settings
        if os.path.exists(settings_path):
            with open(settings_path, 'r') as f:
                content = f.read()
                # Simple comment stripping (// and /* */)
                import re
                content = re.sub(r'//.*', '', content)
                content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
                try:
                    settings = json.loads(content)
                except json.JSONDecodeError:
                    print(f"Error: Could not parse {settings_path}. It might contain comments or be invalid JSON.")
                    print("Aborting to prevent data loss.")
                    sys.exit(1)
        else:
            settings = {}

        # Update workbench.colorCustomizations
        if 'workbench.colorCustomizations' not in settings:
            settings['workbench.colorCustomizations'] = {}
        
        settings['workbench.colorCustomizations'].update(new_colors.get('workbench.colorCustomizations', {}))

        # Write back settings
        with open(settings_path, 'w') as f:
            json.dump(settings, f, indent=4)
            
        print("VS Code settings updated successfully.")

    except Exception as e:
        print(f"Error updating VS Code settings: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Paths
    generated_colors = os.path.expanduser("~/.config/Code/User/matugen-colors.json")
    vscode_settings = os.path.expanduser("~/.config/Code/User/settings.json")
    
    update_vscode_settings(generated_colors, vscode_settings)
